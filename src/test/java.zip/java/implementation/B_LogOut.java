package implementation;

import org.testng.annotations.Test;

import PageObjectModel.driverSetup;

public class B_LogOut extends driverSetup {
	
	@Test
	public void BLogOut() {
		
		driver.quit();
		
	}

}
